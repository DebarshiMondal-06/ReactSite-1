const Jokes = [
  'Orion’s Belt is a huge waist of space.',
  'Atheism is a non-prophet organization.',
  'What’s more amazing than a talking dog? A spelling bee.',
  `I didn't like my beard at first. Then it grew on me.`
];

module.exports = Jokes;